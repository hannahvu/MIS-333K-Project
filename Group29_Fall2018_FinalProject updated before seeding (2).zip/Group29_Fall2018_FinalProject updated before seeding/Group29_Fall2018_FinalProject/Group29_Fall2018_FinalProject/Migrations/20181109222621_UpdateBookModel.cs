﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Group29_Fall2018_FinalProject.Migrations
{
    public partial class UpdateBookModel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
