﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Group29_Fall2018_FinalProject.Migrations
{
    public partial class UpdateNamespace : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "StartDate",
                table: "Genres");

            migrationBuilder.RenameColumn(
                name: "Type",
                table: "Genres",
                newName: "GenreType");

            migrationBuilder.RenameColumn(
                name: "Title",
                table: "Books",
                newName: "BookTitle");

            migrationBuilder.RenameColumn(
                name: "Reorder",
                table: "Books",
                newName: "BookReorder");

            migrationBuilder.RenameColumn(
                name: "PublicationDate",
                table: "Books",
                newName: "BookPublishedDate");

            migrationBuilder.RenameColumn(
                name: "Price",
                table: "Books",
                newName: "BookPrice");

            migrationBuilder.RenameColumn(
                name: "LastOrdered",
                table: "Books",
                newName: "BookLastOrdered");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "Books",
                newName: "BookDescription");

            migrationBuilder.RenameColumn(
                name: "Cost",
                table: "Books",
                newName: "BookCost");

            migrationBuilder.RenameColumn(
                name: "CopiesOnHand",
                table: "Books",
                newName: "BookCopiesOnHand");

            migrationBuilder.RenameColumn(
                name: "Author",
                table: "Books",
                newName: "BookAuthor");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "GenreType",
                table: "Genres",
                newName: "Type");

            migrationBuilder.RenameColumn(
                name: "BookTitle",
                table: "Books",
                newName: "Title");

            migrationBuilder.RenameColumn(
                name: "BookReorder",
                table: "Books",
                newName: "Reorder");

            migrationBuilder.RenameColumn(
                name: "BookPublishedDate",
                table: "Books",
                newName: "PublicationDate");

            migrationBuilder.RenameColumn(
                name: "BookPrice",
                table: "Books",
                newName: "Price");

            migrationBuilder.RenameColumn(
                name: "BookLastOrdered",
                table: "Books",
                newName: "LastOrdered");

            migrationBuilder.RenameColumn(
                name: "BookDescription",
                table: "Books",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "BookCost",
                table: "Books",
                newName: "Cost");

            migrationBuilder.RenameColumn(
                name: "BookCopiesOnHand",
                table: "Books",
                newName: "CopiesOnHand");

            migrationBuilder.RenameColumn(
                name: "BookAuthor",
                table: "Books",
                newName: "Author");

            migrationBuilder.AddColumn<int>(
                name: "StartDate",
                table: "Genres",
                nullable: false,
                defaultValue: 0);
        }
    }
}
