using Group29_Fall2018_FinalProject.Models;
using Group29_Fall2018_FinalProject.DAL;
using System.Collections.Generic;
using System;
using System.Linq;

namespace Group29_Fall2018_FinalProject.Seeding
{
    public static class SeedBooks
    {
        public static void SeedAllBooks(AppDbContext db)
        {
            //check to see if all the languages have already been added
            if (db.Books.Count() == 1)
            {
                //exit the program - we don't need to do any of this
                NotSupportedException ex = new NotSupportedException("Genres record count is already 13!");
                throw ex;
            }
            Int32 intBooksAdded = 0;
            try
            {
                //Create a list of languages
                List<Book> Books = new List<Book>();

                Book b1 = new Book();
                b1.BookPublishedDate = new DateTime(2008, 5, 24);
                b1.BookID = 789001;
                b1.BookTitle = "The Art Of Racing In The Rain";
                b1.BookAuthor = "Garth Stein";
                b1.Genre = db.Genres.FirstOrDefault(x => x.GenreType == "Contemporary Fiction");
                b1.BookDescription = "A Lab-terrier mix with great insight into the human condition helps his owner, a struggling race car driver.";
                b1.BookPrice = 23.95m;
                b1.BookCost = 10.3m;
                b1.BookReorder = 1;
                b1.BookCopiesOnHand = 2;
                b1.BookLastOrdered = new DateTime(2018, 10, 1);
                Books.Add(b1);

                Book b;

                //loop through the list and see which (if any) need to be added
                foreach (Book book in Books)
                {
                    //see if the language already exists in the database
                    b = db.Books.FirstOrDefault(x => x.BookTitle == book.BookTitle);

                    //language was not found
                    if (b == null)
                    {
                        //Add the language
                        db.Books.Add(book);
                        db.SaveChanges();
                        intBooksAdded += 1;
                    }

                }
            }
            catch
            {
                String msg = "Genres Added: " + intBooksAdded.ToString();
                throw new InvalidOperationException(msg);
            }

        }
    }
}
