﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Group29_Fall2018_FinalProject.Models;

namespace Group29_Fall2018_FinalProject.Models
{
    public class Book
    {
        //if don't have to enter the information doesn't need required/formatting requirement 
        //not putting required because user doesn't have to enter this information

        public Int32 BookID { get; set; }

        [DataType(DataType.Date)]
        public DateTime BookPublishedDate { get; set; }
       
        public String BookTitle { get; set; }

        public String BookAuthor { get; set; }
                                     
        public String BookDescription { get; set; }

        //price customer has to pay to buy book 
        //[DataType(DataType.Currency)]
        public Decimal BookPrice { get; set; }

        //price bookstore has to pay to buy books for store
        //[DataType(DataType.Currency)]
        public Decimal BookCost { get; set; }

        //reorder quantity (how many we going to buy for store)
        public Int32 BookReorder { get; set; }

        //numbers in stock 
        public Int32 BookCopiesOnHand { get; set; }

        [DataType(DataType.Date)]
        public DateTime BookLastOrdered { get; set; }


        public virtual List<OrderDetail> OrderDetails { get; set; }
        public virtual Genre Genre { get; set; }
        public virtual ManageOrder ManageOrder { get; set; }
        public virtual List<Review> Reviews { get; set; }



    }
}
