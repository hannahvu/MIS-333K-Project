﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Group29_Fall2018_FinalProject.Models
{
    public class User
    {
        public Int32 UserID { get; set; }

        //makes first name required
        [Required(ErrorMessage = "First name required")]
        [Display(Name = "First Name:")]
        public String FirstName { get; set; }

        //makes last name required
        [Required(ErrorMessage = "Last name required")]
        [Display(Name = "Last Name:")]
        public String LastName { get; set; }

        //makes email address required and requires email format
        [Required(ErrorMessage = "Email required")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email Address")]
        public String Email { get; set; }

        //makes street address required no format 
        [Required(ErrorMessage = "Street address required")]
        [Display(Name = "Street Address")]
        public String StreetAddress { get; set; }

        //makes city required no format
        [Required(ErrorMessage = "City required")]
        [Display(Name = "City")]
        public String City { get; set; }

        //makes state required no format
        [Required(ErrorMessage = "State required")]
        [Display(Name = "State")]
        public String State { get; set; }

        //makes zipcode required no format
        [Required(ErrorMessage = "ZipCode required")]
        [Display(Name = "ZipCope")]
        public String ZipCode { get; set; }

        //makes phone number required with format(this didn't work from hw4)
        [Required(ErrorMessage = "Number required")]
        [DataType(DataType.PhoneNumber)]
        [Display(Name = "Phone Number")]
        [DisplayFormat(DataFormatString = "{0:###-###-####}", ApplyFormatInEditMode = true)]
        public String PhoneNumber { get; set; }

        //makes password required 6 char min
        [Required(ErrorMessage = "Password required")]
        [StringLength( 100, MinimumLength = 6)]
        [Display(Name = "Password")]
        public String Password { get; set; }

        //makes credit card required no format, doesn't say to be required on guidelines
        [Required(ErrorMessage = "CreditCard required")]
        [Display(Name = "CreditCard")]
        public String CreditCard { get; set; }
  
        //gives option to put in a second credit card
        [Display(Name = "CreditCard2")]
        public String CreditCard2 { get; set; }
        
        //gives option to put in a third credit card
        [Display(Name = "CreditCard3")]
        public String CreditCard3 { get; set; }

        //gives option to have a used coupon
        [Display(Name = "UsedCoupon")]
        public String UserCoupon { get; set; }

        //Nagivational properties
        public virtual List<Order> Orders { get; set; }
        //public virtual ListOfReviewsApproved ListOfReviewsApproved { get; set; }
        //public virtual List<ListOfReviews> ListOfReviews{ get; set; }
        //public virtual ManageOrder ManageOrder { get; set; }
        public virtual List<ManageOrder> ManageOrders { get; set; }








    }
}
