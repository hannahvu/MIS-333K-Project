﻿using Group29_Fall2018_FinalProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Group29_Fall2018_FinalProject.Models
{
    public class Coupon
{

    public Int32 CouponID { get; set; }

    //I think we need a coupon code property


    [Required(ErrorMessage = "Please enter Description")]
    public String Description { get; set; }

    [Required(ErrorMessage = "Please enter StartDate")]
    public DataType StartDate { get; set; }

    [Required(ErrorMessage = "Please enter EndDate")]
    public DateTime EndDate { get; set; }

    [Required(ErrorMessage = "Please enter Coupon Type")]
    public String CouponType { get; set; }


    public virtual List<Order> Orders { get; set; }

}

}