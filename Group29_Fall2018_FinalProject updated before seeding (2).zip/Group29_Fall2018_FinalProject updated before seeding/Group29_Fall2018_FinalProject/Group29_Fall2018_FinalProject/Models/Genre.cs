﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Group29_Fall2018_FinalProject.Models;

namespace Group29_Fall2018_FinalProject.Models
{
    public class Genre
    {
        public Int32 GenreID { get; set; }
        
        
        public String GenreType { get; set; }

        ////idk why here or if we need it, not on EF model
        //[Required(ErrorMessage = "Please enter StartDate")]
        //public DataType StartDate { get; set; }

        public virtual List<Book> Books { get; set; }

    }
}