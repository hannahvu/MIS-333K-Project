﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Group29_Fall2018_FinalProject.Models
{
    public class ManageOrder
    {
        //primary key
        public Int32 ManageOrderID { get; set; }

        //have to choose how many copies to order
        [Required(ErrorMessage = "Number of copies required")]
        public Int32 Copies { get; set; }

        //have to select which book
        [Required(ErrorMessage = "Book title required")]
        public String BookTitle { get; set; }

        //made a boolean so if true can't order, if false can order
        [Required(ErrorMessage = "Required")]
        public Boolean DiscountinuedBook { get; set; }

        //not required because should be calculated
        [DataType(DataType.Currency)]
        public Decimal Cost { get; set; }

        public virtual User User { get; set; }
        public virtual List<Book> Books { get; set; }



    }
}
