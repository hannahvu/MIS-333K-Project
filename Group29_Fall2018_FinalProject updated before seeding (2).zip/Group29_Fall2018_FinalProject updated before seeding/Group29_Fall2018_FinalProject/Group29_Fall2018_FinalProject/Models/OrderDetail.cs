﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using Group29_Fall2018_FinalProject.Models;

namespace Group29_Fall2018_FinalProject.Models

{
    public class OrderDetail
    {

        public Int32 OrderDetailID { get; set; }

        //dont know how to make it so less than CopiesOnHand in book class
        [Required(ErrorMessage = "Please enter Quantity")]       
        public Int32 Quantity { get; set; }

        //foreign key?
        public Int32 BookID { get; set; }

        //price should auto populate from book class
        public Decimal Price { get; set; }



        public virtual Order Order { get; set; }
        public virtual Book Book { get; set; }
        public virtual Coupon Coupon { get; set; }

    }

}
