﻿using Group29_Fall2018_FinalProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Group29_Fall2018_FinalProject.Models
{
    public class Order
    {
        //primary key
        public Int32 OrderID { get; set; }
        
        //Idk why we have this/what is it for
        public Int32 CustomerID { get; set; }

        //stores subtotal in currency format
        [DataType(DataType.Currency)]
        public Decimal Subtotal { get; set; }

        //stores shipping cost in currency format
        [DataType(DataType.Currency)]
        public Decimal ShippingCost { get; set; }

        //stores tax in currency format
        [DataType(DataType.Currency)]
        public Decimal Tax { get; set; }

        //stores grandtotal in currency format
        [DataType(DataType.Currency)]
        public Decimal GrandTotal { get; set; }

        public virtual User User { get; set; }
        public virtual List<OrderDetail> OrderDetails { get; set; }
        public virtual Coupon Coupon { get; set; }
       

    }
}
