﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Group29_Fall2018_FinalProject.Models;

namespace Group29_Fall2018_FinalProject.Models
{
    public class Review
    {
        //primary key
        public Int32 ReviewID { get; set; }

        //has to enter rating 1-5
        [Required(ErrorMessage = "Please enter your Rating")]
        [Range(1, 5)]
        public Int32 Rating { get; set; }

        //has to enter a review with no more than 100 char
        [Required(ErrorMessage = "Please enter Review Text")]
        [StringLength(100, MinimumLength =0)]
        public String TextReview { get; set; }

        //I don't even know if we need this
        [Required(ErrorMessage = "Please enter Customer Name")]
        public String CustomerName { get; set; }

        public virtual User User { get; set; }
        public virtual Book Book { get; set; }
        //public virtual Approver Approver { get; set; }

    }

}